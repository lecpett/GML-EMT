import numpy as np


class ESelection:
    def __init__(self, N, W):
        self.N = N
        self.W = W

    def R2Ranking(self, Objs, z_min, z_max):
        Objs = (Objs - z_min) / (z_max - z_min + 1e-10)
        Norm = np.sqrt(np.sum(Objs * Objs, axis=1))
        Rank = []
        for i in range(self.N):
            ASF = np.max(Objs / self.W[i][:], axis=1)
            sorted_indices = np.lexsort((Norm, ASF))
            Rank.append(np.argsort(sorted_indices))
        Rank = np.min(Rank, axis=0)
        return Norm, Rank

    def TournamentSel(self, Objs, z_min, z_max):
        Norm, Rank = self.R2Ranking(Objs, z_min, z_max)
        parents = np.random.randint(0, self.N, (2, self.N))
        sorted_indices = np.lexsort((Rank, Norm))
        rank = np.argsort(sorted_indices)
        sel_parents = [parents[0][i] if rank[parents[0][i]] < rank[parents[1][i]] else parents[1][i] for i in range(parents.shape[1])]
        return np.array(sel_parents)

    def TournamentSelection(self, fitness):
        parents = np.random.randint(0, self.N, (2, self.N))
        sel_parents = [parents[0][i] if fitness[parents[0][i]] > fitness[parents[1][i]] else parents[1][i] for i in range(parents.shape[1])]
        return np.array(sel_parents)
