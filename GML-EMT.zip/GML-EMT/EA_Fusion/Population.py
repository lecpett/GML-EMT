class population_:
    def __init__(self, decs, objs, fits, code, right_index):
        self.Decs = decs
        self.Objs = objs
        self.Fits = fits
        self.Coding = code
        self.Right_index = right_index
