"""TODO."""

from .numbskull import main
main()
