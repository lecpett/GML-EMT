import pickle
from GmlMultiLabel.gml import GML

if __name__ == '__main__':
    ratio = 2
    class_num = 9
    Datasets = ["NCT-CRC-HE-100K"]
    Models = ['densenet201', 'wide_resnet101_2']
    with open("Your path/f_" + Datasets[0] + "_" + str(ratio) + ".pkl", 'rb') as v:
        features = pickle.load(v)
    with open("Your path/v_" + Datasets[0] + "_" + str(ratio) + ".pkl", 'rb') as f:
        variables = pickle.load(f)
    graph = GML.initial("example.config", variables, features, class_num)
    # inference
    graph.inference()
