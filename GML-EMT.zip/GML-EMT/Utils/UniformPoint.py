import numpy as np
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt


class mean_vector:
    # m: the number of dimensions, h: the number of direction
    def __init__(self, N, M):
        self.N = N
        self.M = M

    def perm(self, sequence):
        l1 = sequence
        if len(l1) <= 1:
            return [l1]
        r = []
        for i in range(len(l1)):
            if i != 0 and sequence[i - 1] == sequence[i]:
                continue
            else:
                s = l1[:i] + l1[i + 1:]
                p = self.perm(s)
                for x in p:
                    r.append(l1[i:i + 1] + x)
        return r

    def get_mean_vectors(self):
        # generate the uniform weight vectors
        N = self.N
        M = self.M
        sequence = []
        for ii in range(N):
            sequence.append(0)
        for jj in range(M - 1):
            sequence.append(1)
        ws = []
        pe_seq = self.perm(sequence)
        for sq in pe_seq:
            s = -1
            weight = []
            for i in range(len(sq)):
                if sq[i] == 1:
                    w = i - s
                    w = (w - 1) / N
                    s = i
                    weight.append(w)
            nw = N + M - 1 - s
            nw = (nw - 1) / N
            weight.append(nw)
            if weight not in ws:
                ws.append(weight)
        W = 1 - np.array(ws)
        W[0][0] = 1e-10
        W[N][1] = 1e-10
        return W

    def simple_tsne(self, features, labels, file_name):
        labels_int = labels.astype(int)
        class_colors = [
            '#8ECFC9',  # 薄荷蓝
            '#FFBE7A',  # 奶油橙
            '#FA7F6F',  # 珊瑚红
            '#82B0D2',  # 雾霾蓝
            '#BEB8DC',  # 薰衣草紫
            '#E7DAD2',  # 浅驼色
            '#B2D3C2',  # 青瓷绿
            '#F8A39F',  # 樱花粉
            '#A3D9B1'  # 草木绿
        ]
        points = TSNE(n_components=2).fit_transform(features)
        for i in range(9):
            mask = (labels_int == i)
            plt.scatter(points[mask, 0],
                        points[mask, 1],
                        c=class_colors[i],
                        label=f'Class {i}',
                        alpha=0.7)
        plt.savefig(file_name + '.pdf', format='pdf', dpi=1000, bbox_inches='tight')
        plt.xticks([])
        plt.yticks([])
        plt.show()
